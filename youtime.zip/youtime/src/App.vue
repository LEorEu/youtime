<template>
    <div class="main-content">
      	<router-view></router-view>
    </div>
</template>

<style lang="less">
.main-content{ width: 100%; height: 100%;
}
</style>
